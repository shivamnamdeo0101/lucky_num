import "package:flutter/material.dart";
import './app_screens/firts_screen.dart';

void main() => runApp(new MyFlutterApp());

class MyFlutterApp extends StatelessWidget{


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
        title: "My First Flutter App In Flutter Created On Mahashivratri",
        home: Scaffold(
          appBar:AppBar(title:Text("Flutters"),),

          body: FirstScreen()
        )



    );
  }
}